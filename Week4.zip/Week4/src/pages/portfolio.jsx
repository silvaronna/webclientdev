import AboutSection from "../components/about-section.jsx"
import WorkSection from "../components/work-section.jsx"

export default function Portfolio() {
  return (
    <main className="min-h-screen bg-white">
      <AboutSection />
      <WorkSection />
    </main>
  )
}

